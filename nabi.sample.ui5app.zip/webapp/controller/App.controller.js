sap.ui.define([
	"nabi/sample/ui5app/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("nabi.sample.ui5app.controller.App", {
		
	});
});